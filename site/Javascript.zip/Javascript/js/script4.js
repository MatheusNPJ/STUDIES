// JavaScript Document

function correta(){
	alert("Resposta Correta, parabéns, passou de ano!")
}

function incorreta(){
	alert("Resposta Incorreta, tente novamente!")
}