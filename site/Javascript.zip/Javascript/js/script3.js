// JavaScript Document

function paquita(){
	alert("Seu computador está sendo formatado")
}
