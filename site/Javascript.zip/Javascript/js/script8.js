// JavaScript Document

function  ampliafoto(recfoto){
	document.ampliada.src=recfoto
}