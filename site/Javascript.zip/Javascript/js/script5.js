// JavaScript Document

function peganome(){
	var recnome=document.formdados.camponome.value
	alert("Olá " + recnome + ", seja bem vindo!")
}