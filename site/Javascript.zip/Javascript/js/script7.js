// JavaScript Document

function respcalc(){
	
	//receber os dados do formulário e armazenar em variáveis
	var recv1=Number(document.formcalc.v1.value)
	var recv2=Number(document.formcalc.v2.value)
	var recconta=document.formcalc.conta.value
	
	//verificando a conta escolhida para efetuar
	if(recconta == "mais"){
		var resposta=recv1+recv2
	}else if(recconta == "menos"){
		var resposta=recv1-recv2
	}else if(recconta == "vezes"){
		var resposta=recv1*recv2
	}else if(recconta == "divide"){
		var resposta=recv1/recv2
	}else{
		var resposta="Cálculo Incorreto, favor escolher uma operação."
	}
	alert("Resposta=" + resposta)
}
