// JavaScript Document

//Array serve para armazenar mais de 1 item dentro da variável
var allbanners=Array("imagens/banner1.jpg", "imagens/banner2.jpg", "imagens/banner3.jpg", "imagens/banner4.jpg", "imagens/banner5.jpg")

var alltexto=Array("Levi's", "Colcci", "Hering", "Dudalina", "John John")

var allLinks=Array("https://levi.com.br", "https://colcci.com.br", "https://hering.com.br/store", "https://dudalina.com.br", "https://johnjohndenim.com.br")

//O comando length conta quantos itens tem dentro da variável
var ultimapos=allbanners.length-1

var posatual=-1

function trocabanner(){
	posatual=posatual+1
	if(posatual > ultimapos){
		posatual=0
	}
	document.bannerprincipal.src=allbanners[posatual]
	document.formbanner.textobanner.value=alltexto[posatual]
	setTimeout("trocabanner()", 3000)
}

function clica(){
	window.location=allLinks[posatual]
}




