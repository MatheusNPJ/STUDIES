// JavaScript Document

function mascara(dados, modelo){
	recdados=dados
	gabarito=modelo
	setTimeout("ajustemascara()", 1)
}

function ajustemascara(){
	recdados.value=gabarito(recdados.value)
}

function modelocpf(v){
	v=v.replace(/\D/g, "")//comando para não aceitar letras
	v=v.replace(/(\d{1})(\d{8})$/, "$1.$2")
	v=v.replace(/(\d{1})(\d{5})$/, "$1.$2")
	v=v.replace(/(\d{1})(\d{2})$/, "$1-$2")
	return v
	
}

function foneres(v){
	v=v.replace(/\D/g, "")//comando para não aceitar letras
	v=v.replace(/(\d{1})(\d{8})$/, "$1) $2")
	v=v.replace(/(\d{1})(\d{4})$/, "$1-$2")
	return "(" + v
}
function fonecel(v){
	v=v.replace(/\D/g, "")//comando para não aceitar letras
	v=v.replace(/(\d{1})(\d{9})$/, "$1) $2")
	v=v.replace(/(\d{1})(\d{4})$/, "$1-$2")
	return "(" + v
}
function modelocep(v){
	v=v.replace(/\D/g, "")//comando para não aceitar letras
	v=v.replace(/(\d{1})(\d{3})$/, "$1-$2")	
	return v
}
function buscacep(recebecep){
	recebecep=recebecep.replace(/\D/g, "")//removendo hifen inserido dinamicamente
	url="https://viacep.com.br/ws/" + recebecep + "/json/?callback=preenchecampos"
	criascript=document.createElement("script")
	criascript.src=url
	document.querySelector("head").appendChild(criascript)
}
function preenchecampos(respcorreios){
	if(respcorreios.erro){
		alert("O CEP digitado está incorreto, favor tentar novamente")
	}else{
		document.formvalida.fend.value=respcorreios.logradouro
		document.formvalida.fbairro.value=respcorreios.bairro
		document.formvalida.fuf.value=respcorreios.uf
		
	}
	
	
}



