// JavaScript Document

function pegaidade(){
	var recidade=document.formidade.campoidade.value
	if(recidade >= 18){
		alert("Você é maior de idade, pode navegar!")
		window.location="https://globo.com"
	}else{
		alert("Você é menor de idade, sai fora!")
		window.location="https://play.barbie.com/pt-br"
	}
}